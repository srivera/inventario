package ec.com.comohogar.inventario;

import android.app.Application;

public class SesionAplicacion extends Application {
}
